import React from "react";

export default function HomePage() {
  return <h2>Home Page</h2>;
}
