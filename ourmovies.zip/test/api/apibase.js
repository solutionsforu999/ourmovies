import axios from 'axios';
export default axios.create({
    baseURL:"https://jsonplaceholder.typicode.com/",
});

// "https://api.themoviedb.org/3/discover/movie?api_key=b73db69b1473b998e603b1135a45e51d&with_genres=28"
//"https://api.themoviedb.org/3/https://jsonplaceholder.typicode.com/",